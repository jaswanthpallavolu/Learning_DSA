// C++ program to find the number of islands using DFS

#include <bits/stdc++.h>

using namespace std;

//checks whether the given index is out of the array. Out of array is considered as 0.
bool isSafe(int N, int i, int j)
{
    if (i < 0 || i >= N)
        return false;
    if (j < 0 || j >= N)
        return false;
    return true;
}

//this function does the DFS for every new one 1 found and assign every connected one to zero.
void delIsland(int **A, int N, int i, int j)
{
    if (isSafe(N, i, j) && A[i][j] == 1)
    {
        A[i][j] = 0;
        delIsland(A, N, i - 1, j - 1);
        delIsland(A, N, i - 1, j);
        delIsland(A, N, i - 1, j + 1);
        delIsland(A, N, i, j - 1);
        delIsland(A, N, i, j + 1);
        delIsland(A, N, i + 1, j - 1);
        delIsland(A, N, i + 1, j);
        delIsland(A, N, i + 1, j + 1);
    }
}

int TotalIslands(int **A, int N)
{
    int count = 0;
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
            if (A[i][j] == 1)
            {
                count++;
                delIsland(A, N, i, j);
            }
    }
    if (count == 0)
        return 0;
    return count;
}

int main()
{
    int N;
    cout << "Enter the n value : ";
    cin >> N;
    int **A = (int **)malloc(N * sizeof(int *));
    for (int i = 0; i < N; i++)
        A[i] = (int *)malloc(N * sizeof(int));
    cout << "Enter the island matrix : " << endl;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            cin >> A[i][j];
    cout << "Total Number of islands : " << TotalIslands(A, N) << endl;
    return 0;
}