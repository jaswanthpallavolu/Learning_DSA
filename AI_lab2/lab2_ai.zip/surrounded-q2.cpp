// A C++ program to replace all 'O's with 'X''s if surrounded by 'X'
#include <iostream>
using namespace std;

// Size of given matrix is M X N
#define M 4
#define N 4

// A recursive function to replace previous value 'prevV' at '(x, y)'
// and all surrounding values of (x, y) with new value 'newV'.
void floodFillUtil(int mat[][N], int x, int y, int prevV, int newV)
{
    // Base cases
    if (x < 0 || x >= M || y < 0 || y >= N)
        return;
    if (mat[x][y] != prevV)
        return;

    // Replace the color at (x, y)
    mat[x][y] = newV;

    // Recur for north, east, south and west
    floodFillUtil(mat, x + 1, y, prevV, newV);
    floodFillUtil(mat, x - 1, y, prevV, newV);
    floodFillUtil(mat, x, y + 1, prevV, newV);
    floodFillUtil(mat, x, y - 1, prevV, newV);
}

// Returns size of maximum size subsquare matrix
// surrounded by 'X'
int replaceSurrounded(int mat[][N])
{
    // Step 1: Replace all 'O' with '-'
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++)
            if (mat[i][j] == 0)
                mat[i][j] = 5;

    // Call floodFill for all '-' lying on edges
    for (int i = 0; i < M; i++) // Left side
        if (mat[i][0] == 5)
            floodFillUtil(mat, i, 0, 5, 1);
    for (int i = 0; i < M; i++) // Right side
        if (mat[i][N - 1] == 5)
            floodFillUtil(mat, i, N - 1, 5, 1);
    for (int i = 0; i < N; i++) // Top side
        if (mat[0][i] == 5)
            floodFillUtil(mat, 0, i, 5, 1);
    for (int i = 0; i < N; i++) // Bottom side
        if (mat[M - 1][i] == 5)
            floodFillUtil(mat, M - 1, i, 5, 1);

    // Step 3: Replace all '-' with 'X'
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++)
            if (mat[i][j] == 5)
                mat[i][j] = 0;
    return 0;
}

// Driver program to test above function
int main()
{

    int mat[M][N];

    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++)
            cin >> mat[i][j];

    replaceSurrounded(mat);
    cout << endl;
    for (int i = 0; i < M; i++)
    {
        for (int j = 0; j < N; j++)
            cout << mat[i][j] << " ";
        cout << endl;
    }
    return 0;
}
